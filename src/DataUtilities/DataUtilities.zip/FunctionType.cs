using System;
using System.Collections.Generic;
using System.Text;

namespace SEFI.Infrastructure.Common.Enums
{
    public enum FunctionType
    {
        Get,
        GetAll
    }
}
