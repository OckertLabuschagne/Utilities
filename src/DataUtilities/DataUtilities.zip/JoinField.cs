using System;
using System.Collections.Generic;
using System.Text;

namespace SEFI.Infrastructure.Common.DataUtilities
{
	public class JoinField
	{
		public string FieldName { get; set; }
		public string ForeignFieldName { get; set; }
	}
}
