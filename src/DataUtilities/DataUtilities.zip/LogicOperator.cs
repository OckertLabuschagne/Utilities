using System;
using System.Collections.Generic;
using System.Text;

namespace SEFI.Infrastructure.Common.Enums
{
    public enum LogicOperator: int
    {
        And = 0,
        Or = 1,
        Empty = 2
    }
}
