using System;
using System.Collections.Generic;
using System.Text;

namespace SEFI.Infrastructure.Common.Enums
{
	public enum SQLJoinTypes
	{
		INNER,
		LEFT,
		RIGHT,
		FULL,
		SELF
	}
}
